const miarray =['juan','andres','laura']
console.log(miarray)

const miSet = new Set(miarray)
console.log(miSet)

miSet.add('kiki')
console.log(miSet)

miSet.add('juan')
console.log(miSet)

miSet.add('Javascript')
console.log(miSet)
